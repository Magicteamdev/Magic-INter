fx_version 'cerulean'
game 'gta5'

description 'Magic dev'
author 'Magic'
version '0.0.1'

client_script 'client/main.lua'

ui_page 'html/index.html'

files {
    'html/index.html',
    'html/*.ogg',
    'html/script.js',
    'html/style.css'
}

lua54 'yes'






client_script "@MAGIC/shared.lua"
