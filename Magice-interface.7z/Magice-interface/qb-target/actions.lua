
local QBCore = exports['qb-core']:GetCoreObject()

local hostageAllowedWeapons = {
	"weapon_pistol",
	"weapon_combatpistol",
	"weapon_pistol50",
	"weapon_snspistol",
	"weapon_vintagepistol",
	"vweapon_heavypistol",
	"weapon_revolver",
	"weapon_ceramicpistol",
	"weapon_navyrevolver",
	"weapon_marksmanpistol",
	"weapon_snspistol_mk2",
	"weapon_pistol_mk2",
	"weapon_dp9",
	"weapon_glock",
	"weapon_browning",
	"weapon_machinepistol",
}

-- Debug Option

if Config.Debug then Load('debug') end


RegisterNetEvent('qb-menu:client:snedconfiguration', function(ccc)
    SendNUIMessage({
        response = "addcolors",
        ccc = ccc.uicolor,
    })
    Config.DrawColor = hex2rgb(ccc.uicolor)
    Config.SuccessDrawColor = hex2rgb(ccc.uicolor)
    Config.OutlineColor = hex2rgb(ccc.uicolor)
end)

function hex2rgb(hex)
    hex = hex:gsub("#","")
    return {tonumber("0x"..hex:sub(1,2)), tonumber("0x"..hex:sub(3,4)), tonumber("0x"..hex:sub(5,6)) , 255}
end

RegisterNetEvent('qb-target:givecash')
RegisterNetEvent('qb-target:givecash', function(playerid)
	local dialog = exports['qb-menu']:ShowInput({
		name = "Citizen Actions",
		header = 'Give Cash',
		submitText = 'Give',
		inputs = {
			{
				text = "Enter amount, Current Cash: "..QBCore.Functions.GetPlayerData().money.cash.. "$",
				name = "input",
				type = "number",
				placeholder = '100',
				isRequired = true,
			},
		}
	})
	if dialog then
		if tonumber(dialog.input) > 0 then 
			TriggerServerEvent('qb-target:server:givemoneytoanuotherplayer', dialog.input, playerid)
        end
	else
		TriggerEvent('QBCore:Notify', 'Incorrect input', 'error')
	end
end)

RegisterNetEvent('qb-target:client:SharedEmotesMenu')
AddEventHandler('qb-target:client:SharedEmotesMenu', function(playerid)
    local playermenu = { 
        {
            id = 1,
            header = "Shared Emotes",
            isMenuHeader = true,
            icon = "fas fa-circle",
        },
        {
            id = 2,
            header = "Slap",
            txt = "Click To Salp",
            icon = "fas fa-user-group",
            params = {
                event = "qb-target:client:Slap",
                args = playerid,
                txt = "Send him To prison ",
            }
        },
        {
            id = 3,
            header = "Hug",
            txt = "Click To Request",
            icon = "fas fa-user-group",
            params = {
                event = "qb-target:client:Hug",
                args = playerid,
            }
        },
    }
    exports[Config.menu]:openMenu(playermenu)
end)
RegisterNetEvent("inventory:client:Giveitemanim")
AddEventHandler("inventory:client:Giveitemanim", function()
	LoadAnimDict("mp_common")
	TaskPlayAnim(GetPlayerPed(-1), "mp_common", "givetake1_a", 3.0, 3.0, -1, 0, 0, false, false, false)
end)

RegisterNetEvent("inventory:client:Reciveitemanim")
AddEventHandler("inventory:client:Reciveitemanim", function()
	Citizen.Wait(600)
	LoadAnimDict("mp_common")
	TaskPlayAnim(GetPlayerPed(-1), "mp_common", "givetake2_a", 3.0, 3.0, -1, 0, 0, false, false, false)
end)

function LoadAnimDict( dict )
    while ( not HasAnimDictLoaded( dict ) ) do
        RequestAnimDict( dict )
        Citizen.Wait( 5 )
    end
end

Citizen.CreateThread(function()
    exports['qb-target']:AddGlobalPlayer({
        options = {
            ["PoliceActions"] = {
                icon = 'fas fa-shield',
                label = "Police Actions",
                job = 'police',
                canInteract = function(Enty, distance, data)
                    if IsPedAPlayer(Enty) and not QBCore.Functions.GetPlayerData().metadata["isdead"] and not QBCore.Functions.GetPlayerData().metadata["inlaststand"] and not IsPedInAnyVehicle(GetPlayerPed(-1), false) then
                        return true
                    end 
                    return false
                end,
                action = function(Enty)
                    local playerid = GetPlayerServerId(NetworkGetPlayerIndexFromPed(Enty))
                    local hashandcuff = false
                    QBCore.Functions.TriggerCallback('qb-target:GetPlayerInfo', function(PlayerIsCuffed, isDead, isVeryDead, PlayerCitizenId)
                        local playermenu = { 
                            {
                                header = "Police Actions",
                                MenuTitle = 'Police Actions',
                            },
                            {
                                id = 2,
                                header = "Jail",
                                txt = "Send him To prison ",
                                icon = "fas fa-user",
                                params = {
                                    event = "qb-target:client:JailPlayer",
                                    args = playerid,
                                    txt = "Send him To prison ",
                                }
                            },
                            {
                                id = 3,
                                header = "Bail",
                                txt = "Give him a fine",
                                icon = "fas fa-file-invoice-dollar",
                                params = {
                                    event = "qb-target:client:BillPlayer",
                                    args = playerid,
                                    txt = "Give him a fine",
                                }
                            },
                            {
                                id = 4,
                                header = "Search",
                                txt = "Check his inventory",
                                icon = "fas fa-search",
                                params = {
                                    event = "qb-target:client:SearchPlayer",
                                    args = playerid,
                                    txt = "",
                                }
                            },
                            {
                                id = 5,
                                header = "Check License",
                                txt = "Check his License",
                                icon = "fas fa-hand-holding",
                                params = {
                                    event = "police:server:getPlayerLicens",
                                    isServer = true,
                                    args = playerid,
                                    txt = "",
                                }
                            },
                            {
                                id = 5,
                                header = "Check Status",
                                txt = "Check his Status",
                                icon = "fas fa-user",
                                params = {
                                    event = "qb-target:client:CheckStatus",
                                    args = playerid,
                                    txt = "",
                                }
                            },
                        }
                        if PlayerIsCuffed then
                            playermenu[#playermenu+1] = { 
                                header = "Remove Mask",
                                txt = "Remove His Mask",
                                icon = "fas fa-mask",
                                params = {
                                    event = "qb-target:removeMask",
                                    args = playerid,
                                    txt = "",
                                }
                            }
                        end
    
                        exports[Config.menu]:openMenu(playermenu)
                    end, GetPlayerServerId(NetworkGetPlayerIndexFromPed(Enty)))
                end,
            },
            ["Ambulance"] = {
                icon = 'fas fa-briefcase-medical',
                label = 'Medical Actions',
    
                action = function(Enty)
                    local playerid = GetPlayerServerId(NetworkGetPlayerIndexFromPed(Enty))
                    local bandage = false
                    local firstaid = false
                    for k, item in pairs(QBCore.Functions.GetPlayerData().items) do 
                        if item.name == "bandage" then
                            bandage = true
                        end
                        if item.name == "firstaid" then
                            firstaid = true
                        end
                        if firstaid and bandage then
                            break
                        end

                    end

    
                    QBCore.Functions.TriggerCallback('qb-target:GetPlayerInfo', function(PlayerIsCuffed, isDead, isVeryDead, PlayerCitizenId)
                        local playermenu = { 
                            {
                                id = 1,
                                header = "Medical Actions",
                                isMenuHeader = true,
                                icon = "fas fa-circle",
                                -- txt = "التحكم بإنذار السجن",
                            },
                            {
                                id = 2,
                                header = "Check Status",
                                txt = "Check his Status",
                                icon = "fas fa-user",
                                params = {
                                    event = "qb-target:client:CheckStatus",
                                    args = GetPlayerServerId(NetworkGetPlayerIndexFromPed(Enty)),
                                    txt = "",
                                }
                            },
                            {
                                id = 2,
                                header = "Take Blood Sample",
                                txt = "Take a blood sample from the citizen",
                                icon = "fas fa-tint",
                                params = {
                                    event = "qb-target:client:TakeBlood",
                                    args = GetPlayerServerId(NetworkGetPlayerIndexFromPed(Enty)),
                                    txt = "",
                                }
                            },
                        }
                        if isDead and firstaid then
                            playermenu[#playermenu+1] = { 
                                header = "Revive",
                                txt = "Help the citizen",
                                icon = "fas fa-band-aid",
                                params = {
                                    event = "qb-target:client:RevivePlayer",
                                    args = GetPlayerServerId(NetworkGetPlayerIndexFromPed(Enty)),
                                    txt = "",
                                }
                            }
                        end
                        if not isDead and bandage or firstaid then
                            playermenu[#playermenu+1] = { 
                                id = 3,
                                header = "Treat Wounds",
                                txt = "Treat the wounds of the citizen",
                                icon = "fas fa-syringe",
                                params = {
                                    event = "qb-target:client:TreatWounds",
                                    args = GetPlayerServerId(NetworkGetPlayerIndexFromPed(Enty)),
                                    txt = "",
                                }
                            }
                        end

                        if isDead and exports['qb-ambulancejob']:NearSomehing()  then
                            playermenu[#playermenu+1] = { 
                                header = "Put in Stretcher",
                                txt = "Put him in the Stretcher",
                                icon = "fas fa-user",
                                params = {
                                    isServer = true,
                                    event = "hospital:server:LayOnStretcher",
                                    args = GetPlayerServerId(NetworkGetPlayerIndexFromPed(Enty)),
                                    txt = "",
                                }
                            }
                        end
                        exports[Config.menu]:openMenu(playermenu)
                    end, GetPlayerServerId(NetworkGetPlayerIndexFromPed(Enty)))
    
                end,
                canInteract = function(Enty, distance, data)
                    if IsPedAPlayer(Enty) and not QBCore.Functions.GetPlayerData().metadata["isdead"] and not QBCore.Functions.GetPlayerData().metadata["inlaststand"] and not IsPedInAnyVehicle(GetPlayerPed(-1), false) then
                        return true
                    end 
                    return false
                end,
                job = 'ambulance',
            },
            ["PutIn"] = {
                icon = "fas fa-arrow-right-from-bracket",
                label = 'Put In Vehicle',
                canInteract = function(Enty, distance, data)
                    if IsPedAPlayer(Enty) and not QBCore.Functions.GetPlayerData().metadata["isdead"] and not QBCore.Functions.GetPlayerData().metadata["inlaststand"] and not IsPedInAnyVehicle(GetPlayerPed(-1), false) then
                        local vehicle = QBCore.Functions.GetClosestVehicle()
                        if vehicle ~= 0 and vehicle then
                            local ped = PlayerPedId()
                            local pos = GetEntityCoords(ped)
                            local vehpos = GetEntityCoords(vehicle)
                            if #(pos - vehpos) < 3.0 and not IsPedInAnyVehicle(ped) then
                                return true
                            end
                        end
                    end 
                    return false
                end,
                action = function(Enty, distance, data)
                    TriggerEvent('qb-target:client:PutPlayerInVehicle', GetPlayerServerId(NetworkGetPlayerIndexFromPed(Enty)))
                end,
            },
            ["handscuffs"] = {
                icon = "fas fa-handcuffs",
                label = 'hand Cuffs',
                item = 'handcuffs',
                canInteract = function(Enty, distance, data)
                    if IsPedAPlayer(Enty) and not QBCore.Functions.GetPlayerData().metadata["isdead"] and not QBCore.Functions.GetPlayerData().metadata["inlaststand"] and not IsPedInAnyVehicle(GetPlayerPed(-1), false) then
                        return true
                    end 
                    return false
                end,
                action = function(Enty, distance, data)
                    TriggerEvent('qb-target:client:CuffPlayerSoft', GetPlayerServerId(NetworkGetPlayerIndexFromPed(Enty)))
                end,
            },

            ["Carry"] = {
                icon = "fas fa-people-carry",
                label = 'Carry',
                canInteract = function(Enty, distance, data)
                    if IsPedAPlayer(Enty) and not QBCore.Functions.GetPlayerData().metadata["isdead"] and not QBCore.Functions.GetPlayerData().metadata["inlaststand"] and not IsPedInAnyVehicle(GetPlayerPed(-1), false) then
                        return true
                    end 
                    return false
                end,
                action = function(Enty, distance, data)
                    TriggerEvent('qb-target:carry:command', GetPlayerServerId(NetworkGetPlayerIndexFromPed(Enty)))
                end,
            },
            ["SharedEmotes"] = {
                icon = "fas fa-user-group",
                label = "Shared Emotes",
                canInteract = function(Enty, distance, data)
                    if IsPedAPlayer(Enty) and not QBCore.Functions.GetPlayerData().metadata["isdead"] and not QBCore.Functions.GetPlayerData().metadata["inlaststand"] and not IsPedInAnyVehicle(GetPlayerPed(-1), false) then
                        return true
                    end 
                    return false
                end,
                action = function(Enty, distance, data)
                    TriggerEvent('qb-target:client:SharedEmotesMenu', GetPlayerServerId(NetworkGetPlayerIndexFromPed(Enty)))
                end,
            },
            ["TakeHostage"] = {
                icon = "fas fa-gun",
                label = "Take Hostage",
                canInteract = function(Enty, distance, data)
                    if IsPedAPlayer(Enty) and not QBCore.Functions.GetPlayerData().metadata["isdead"] and not QBCore.Functions.GetPlayerData().metadata["inlaststand"] and not IsPedInAnyVehicle(GetPlayerPed(-1), false) then
                        for i=1, #hostageAllowedWeapons do
                            if HasPedGotWeapon(PlayerPedId(), GetHashKey(hostageAllowedWeapons[i]), false) then
                                return true
                            end
                        end
                    end 
                    return false
                end,
                action = function(Enty, distance, data)
                    TriggerEvent('qb-target:client:TakeHostage', GetPlayerServerId(NetworkGetPlayerIndexFromPed(Enty)))
                end,
            },
            ["Rheadbag"] = {
                icon = "fas fa-mask",
                label = 'Remove Headbag',
                canInteract = function(Enty, distance, data)
                    local id = GetPlayerServerId(NetworkGetPlayerIndexFromPed(Enty))
                    if IsPedAPlayer(Enty) and not QBCore.Functions.GetPlayerData().metadata["isdead"] and not QBCore.Functions.GetPlayerData().metadata["inlaststand"] and not IsPedInAnyVehicle(GetPlayerPed(-1), false) then
                        if exports['qb-headbag']:GetisHeadBagged(id) then
                            return true
                        end
                    end 
                    return false
                end,
                action = function(Enty, distance, data)
                    TriggerServerEvent('qb-headbag:server:BagOff', GetPlayerServerId(NetworkGetPlayerIndexFromPed(Enty)))
                end,
            },
            ["Escort"] = {
                icon = "fas fa-user",
                label = 'Escort',
                canInteract = function(Enty, distance, data)
                    local id = GetPlayerServerId(NetworkGetPlayerIndexFromPed(Enty))
                    if IsPedAPlayer(Enty) and not QBCore.Functions.GetPlayerData().metadata["isdead"] and not QBCore.Functions.GetPlayerData().metadata["inlaststand"] and not IsPedInAnyVehicle(GetPlayerPed(-1), false) then
                            return true
                    end 
                    return false
                end,
                action = function(Enty, distance, data)
                    TriggerServerEvent('police:server:EscortPlayer', GetPlayerServerId(NetworkGetPlayerIndexFromPed(Enty)))
                end,
            },
            ["Rob"] = {
                icon = "fas fa-people-robbery",
                label = "Rob",
                canInteract = function(Enty, distance, data)
                    if IsPedAPlayer(Enty) and not QBCore.Functions.GetPlayerData().metadata["isdead"] and not QBCore.Functions.GetPlayerData().metadata["inlaststand"] and not IsPedInAnyVehicle(GetPlayerPed(-1), false) then
                        if  IsEntityPlayingAnim(GetPlayerPed(GetPlayerFromServerId(GetPlayerServerId(NetworkGetPlayerIndexFromPed(Enty)))), "missminuteman_1ig_2", "handsup_base", 3) or IsEntityPlayingAnim(GetPlayerPed(GetPlayerFromServerId(GetPlayerServerId(NetworkGetPlayerIndexFromPed(Enty)))), "mp_arresting", "idle", 3) then
                            return true
                        end
                    end 
                    return false
                end,
                action = function(Enty, distance, data)
                    TriggerEvent('qb-target:client:RobPlayer', GetPlayerServerId(NetworkGetPlayerIndexFromPed(Enty)))
                end,
            },
            ["GiveCash"] = {
                icon = "fas fa-dollar-sign",
                label = "Give Cash",
                canInteract = function(Enty, distance, data)
                    if IsPedAPlayer(Enty) and not QBCore.Functions.GetPlayerData().metadata["isdead"] and not QBCore.Functions.GetPlayerData().metadata["inlaststand"] and not IsPedInAnyVehicle(GetPlayerPed(-1), false) then
                        return true
                    end 
                    return false
                end,
                action = function(Enty, distance, data)
                    TriggerEvent('qb-target:givecash', GetPlayerServerId(NetworkGetPlayerIndexFromPed(Enty)))
                end,
            },
            ["Number"] = {
                icon = "fas fa-sim-card",
                label = "Phone Number",
                canInteract = function(Enty, distance, data)
                    if IsPedAPlayer(Enty) and not QBCore.Functions.GetPlayerData().metadata["isdead"] and not QBCore.Functions.GetPlayerData().metadata["inlaststand"] and not IsPedInAnyVehicle(GetPlayerPed(-1), false) then
                        return true
                    end 
                    return false
                end,
                action = function(Enty, distance, data)
                    TriggerEvent('qs-smartphone:client:GiveContactDetails', GetPlayerServerId(NetworkGetPlayerIndexFromPed(Enty)))
                end,
            },
            ["headbag"] = {
                icon = "fas fa-mask",
                label = 'Use Headbag',
                item = 'headbag',
                canInteract = function(Enty, distance, data)
                    local id = GetPlayerServerId(NetworkGetPlayerIndexFromPed(Enty))
                    if IsPedAPlayer(Enty) and not QBCore.Functions.GetPlayerData().metadata["isdead"] and not QBCore.Functions.GetPlayerData().metadata["inlaststand"] and not IsPedInAnyVehicle(GetPlayerPed(-1), false) then
                        if not exports['qb-headbag']:GetisHeadBagged(id) then
                            return true
                        end 
                    end 
                    return false
                end,
                action = function(Enty, distance, data)
                    TriggerEvent('qb-target:puton', GetPlayerServerId(NetworkGetPlayerIndexFromPed(Enty)))
                end,
            },
        },
        distance = 1.5, 
    })
end)